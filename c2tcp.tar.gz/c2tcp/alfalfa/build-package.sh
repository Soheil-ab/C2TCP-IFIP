#!/bin/sh

git-buildpackage --git-upstream-branch=master --git-upstream-tree=branch
