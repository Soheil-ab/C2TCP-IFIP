D[0]="with labels offset 0,-1 tc rgb \"red\" point pointtype 1 ps 1 lc rgb \"red\""
#Codel
D[1]="with labels offset -7,0 tc rgb \"green\" point pointtype 12 ps 1 lc rgb \"black\""
#c2Tcp
D[2]="with labels offset -4,0 tc rgb \"blue\" point pointtype 3 ps 1 lc rgb \"blue\""

