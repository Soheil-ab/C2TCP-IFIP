D[0]="with labels offset 0,-1 tc rgb \"red\" point pointtype 1 ps 1 lc rgb \"red\""
#Reno
D[1]="with labels offset 5,-1 tc rgb \"black\" point pointtype 4 ps 1 lc rgb \"black\""
#vegas
D[2]="with labels offset -1,1 tc rgb \"green\" point pointtype 2 ps 1 lc rgb \"green\""
#Verus
D[3]="with labels offset 0,-1 tc rgb \"violet\" point pointtype 7 ps 1 lc rgb \"violet\""
#Sprout
D[4]="with labels offset -5,0 tc rgb \"orange\" point pointtype 5 ps 1 lc rgb \"orange\""
#Codel
D[5]="with labels offset -7,0 tc rgb \"black\" point pointtype 12 ps 1 lc rgb \"black\""
#c2Tcp
D[6]="with labels offset -4,0 tc rgb \"blue\" point pointtype 3 ps 1 lc rgb \"blue\""
#c2Tcp
D[7]="with labels offset -4,0 tc rgb \"blue\" point pointtype 3 ps 1 lc rgb \"blue\""
#c2Tcp
D[8]="with labels offset -4,0 tc rgb \"blue\" point pointtype 3 ps 1 lc rgb \"blue\""
#LEDBAT
D[9]="with labels offset 4,0 tc rgb \"lime green\" point pointtype 9 ps 1 lc rgb \"lime green\""

